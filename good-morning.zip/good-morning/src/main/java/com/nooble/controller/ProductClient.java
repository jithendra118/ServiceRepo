package com.nooble.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name="good-afternoon")
public interface ProductClient {

	
	@GetMapping("/noon/message")
    public String getMessage();
}
