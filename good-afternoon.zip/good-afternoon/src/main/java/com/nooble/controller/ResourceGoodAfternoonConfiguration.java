/**
 * @Author Vinu Sagar Maintained by Nooble ®
 * Licensed to Notyfyd
 */

package com.nooble.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.provider.token.RemoteTokenServices;

@Configuration
@EnableResourceServer
public class ResourceGoodAfternoonConfiguration extends ResourceServerConfigurerAdapter {
	
	
	@Value("${oauth.url}")
    public String oauthURlcheck;
    @Override
    public void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .authorizeRequests()
                .antMatchers("/oauth/**,/actuator/refresh")
                .permitAll()
                .antMatchers("/")
                .authenticated();
    }
    @Bean
    public RemoteTokenServices tokenGoodAfternoonService() {
        RemoteTokenServices tokenService = new RemoteTokenServices();
        //NoonController nq = new NoonController();
        oauthURlcheck= oauthURlcheck.trim();
        	tokenService.setCheckTokenEndpointUrl(oauthURlcheck);	
        
        
        tokenService.setClientId("client");
        tokenService.setClientSecret("secret");
        return tokenService;
    }
}
